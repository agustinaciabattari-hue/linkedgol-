import { Router, type IRouter } from "express";
import healthRouter from "./health";
import playersRouter from "./players";
import opportunitiesRouter from "./opportunities";
import adminRouter from "./admin";
import authRouter from "./auth";
import contactRouter from "./contact";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(playersRouter);
router.use(opportunitiesRouter);
router.use(adminRouter);
router.use(contactRouter);

export default router;
